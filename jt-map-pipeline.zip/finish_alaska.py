"""Loudnorm the boosted Alaska mix, mux onto the silent video, measure."""
import json
import subprocess
from pathlib import Path

ROOT = Path("/home/ubuntu/jt/work/alaska")
BOOST = ROOT / "boosted.wav"
SILENT = ROOT / "silent.mp4"
NORM = ROOT / "norm.wav"
FINAL = ROOT / "alaska_final.mp4"


def run(cmd):
    print(" ".join(cmd[:8]), "...")
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stderr[-2000:])
        raise SystemExit(r.returncode)
    return r.stderr + r.stdout


def loudnorm():
    probe = run([
        "ffmpeg", "-hide_banner", "-i", str(BOOST),
        "-af", "loudnorm=I=-14:TP=-2.0:LRA=11:print_format=json",
        "-f", "null", "-",
    ])
    start = probe.rfind("{")
    end = probe.rfind("}")
    measured = json.loads(probe[start:end + 1])
    af = (
        "loudnorm=I=-14:TP=-2.0:LRA=11:"
        f"measured_I={measured['input_i']}:measured_TP={measured['input_tp']}:"
        f"measured_LRA={measured['input_lra']}:measured_thresh={measured['input_thresh']}:"
        f"offset={measured['target_offset']}:linear=true"
    )
    run([
        "ffmpeg", "-y", "-hide_banner", "-i", str(BOOST),
        "-af", af, "-ar", "48000", "-ac", "2", str(NORM),
    ])
    (ROOT / "loudnorm_measured.json").write_text(json.dumps(measured, indent=1))


def mux():
    run([
        "ffmpeg", "-y", "-hide_banner",
        "-i", str(SILENT), "-i", str(NORM),
        "-map", "0:v:0", "-map", "1:a:0",
        # 192 kbps AAC lifted a -3.0 dBTP wav to -0.2 on this ffmpeg. 320k kept -3.0.
        "-c:v", "copy", "-c:a", "aac", "-b:a", "320k", "-ar", "48000",
        "-t", "20.2",
        "-movflags", "+faststart",
        str(FINAL),
    ])


if __name__ == "__main__":
    loudnorm()
    mux()
    print("final", FINAL, FINAL.stat().st_size)
