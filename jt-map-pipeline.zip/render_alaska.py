"""Alaska map-fact final. Reuses the existing mixed audio; new picture only.

Acceptance (review map-6 (b), plus the shared tech spec):
- claim and labels x <= 900
- 180 meridian is not a text colour and stays off the right-hand text detector
- beats 6-8 keep moving (no frozen tail)
- karaoke glyphs >= 56 px, groups of 1-3 words, active word yellow
- EAST / ALASKA word-end gain on the reused mix
- 1080x1920 30 fps H.264 bt709, -14 LUFS, TP <= -1.5
- last frame equals frame 0
"""
import json
import math
import os
import subprocess
import sys

import numpy as np
import skia

sys.path.insert(0, "/home/ubuntu/jt/pipeline")
from jt.earth import build_texture, paint_globe, project

W, H, FPS = 1080, 1920, 30
DUR = 20.2
N = int(round(DUR * FPS))  # 606
FONT_BLACK = "/usr/share/fonts/opentype/inter/Inter-Black.otf"
FONT_XB = "/usr/share/fonts/opentype/inter/Inter-ExtraBold.otf"
FONT_MED = "/usr/share/fonts/opentype/inter/Inter-Medium.otf"
YELLOW = (255, 214, 10, 255)
WHITE = (244, 247, 251, 255)
SUB = (186, 198, 214, 255)
# Right edge of every text pixel. 880 leaves margin under the 900 rule.
TEXT_R = 880
TEXT_L = 64

# Camera keys: t, lon, lat, radius px. Last key matches the first so the
# loop crossfade lands on the opening globe.
KEYS = [
    (0.00, -98.0, 46.0, 460),
    (2.36, -67.0, 44.8, 860),
    (4.08, -151.0, 63.0, 640),
    (5.76, 178.0, 52.6, 1100),
    (9.09, 180.0, 52.3, 1500),
    (11.16, -179.11, 51.26, 2300),
    (13.69, 179.77, 51.96, 2500),
    (15.60, 168.0, 55.0, 820),
    (18.06, -130.0, 52.0, 520),
    (20.20, -98.0, 46.0, 460),
]

# On-screen facts. Longitudes checked this session:
# Pochnoi Point GNIS 51.9589 N, 179.7706 E (51°57'32"N 179°46'14"E)
# Amatignak Island GNIS 51.2622 N, 179.1086 W (51°15'44"N 179°06'31"W)
# West Quoddy Head lighthouse Wikipedia 44.8151 N, 66.9505 W
MARKS = {
    "maine": (44.8151, -66.9505, "MAINE"),
    "amatignak": (51.2622, -179.1086, "AMATIGNAK"),
    "pochnoi": (51.9589, 179.7706, "POCHNOI"),
}

BEATS = [
    (0.00, "Which US state is\nfarthest *EAST?*", "Hint: it's not where you think", None),
    (2.36, "*MAINE?*\nNot by longitude", "The textbook answer", "maine"),
    (4.08, "By longitude:\n*ALASKA*", "Yes, really", None),
    (5.76, "The Aleutians cross\nthe *180°* line", "Halfway around the world", None),
    (9.09, "West turns\ninto *EAST*", "Cross 180° and the sign flips", None),
    (11.16, "Alaska is the\n*WESTERNMOST* state", "Amatignak · 179°06′W", "amatignak"),
    (13.69, "AND the\n*EASTERNMOST*", "Pochnoi Point · 179°46′E", "pochnoi"),
    (15.60, "The only state in the\n*EASTERN* Hemisphere", "Thanks to the Aleutians", None),
    (18.06, "Which US state is\nfarthest *EAST?*", "Hint: it's not where you think", None),
]


def smooth(u):
    u = max(0.0, min(1.0, u))
    return u * u * (3 - 2 * u)


def ang_lerp(a, b, u):
    d = (b - a + 180.0) % 360.0 - 180.0
    return a + d * u


def camera(t):
    """Hold each key, then fly to the next one in the last 0.7 s. Drift on the hold."""
    t = max(0.0, min(DUR, t))
    k = 0
    for i in range(len(KEYS) - 1):
        if t >= KEYS[i + 1][0]:
            k = i + 1
    if k >= len(KEYS) - 1:
        lon, lat, rad = KEYS[-1][1:]
    else:
        t_next = KEYS[k + 1][0]
        flight = 0.70
        if t > t_next - flight:
            u = smooth((t - (t_next - flight)) / flight)
            lon = ang_lerp(KEYS[k][1], KEYS[k + 1][1], u)
            lat = KEYS[k][2] + (KEYS[k + 1][2] - KEYS[k][2]) * u
            rad = KEYS[k][3] + (KEYS[k + 1][3] - KEYS[k][3]) * u
        else:
            lon, lat, rad = KEYS[k][1:]
            direction = 1.0 if (k % 2 == 0) else -1.0
            speed = 0.45 if rad > 1400 else 1.05
            lon += direction * speed * (t - KEYS[k][0])
            lat += 0.12 * math.sin((t - KEYS[k][0]) * 1.8)
            rad *= 1.0 + 0.012 * math.sin(t * 2.0)
    # Tiny continuous wobble so a flight ease-in never sits still for 0.4 s.
    lon += 0.18 * math.sin(t * 3.1)
    return lon, lat, rad


def set_rgba(paint, color):
    r, g, b, a = color
    paint.setColor(skia.ColorSetARGB(a, r, g, b))


def face(path, size):
    return skia.Font(skia.Typeface.MakeFromFile(path), size)


def parse_line(s):
    parts, buf, acc = [], "", False
    for ch in s:
        if ch == "*":
            if buf:
                parts.append((buf, acc))
                buf = ""
            acc = not acc
        else:
            buf += ch
    if buf:
        parts.append((buf, acc))
    return parts


def text_width(font, s):
    return font.measureText(s)


def draw_line(canvas, parts, x, y, font, max_right):
    cursor = x
    for text, accent in parts:
        paint = skia.Paint(AntiAlias=True)
        col = YELLOW if accent else WHITE
        set_rgba(paint, col)
        w = text_width(font, text)
        if cursor + w > max_right:
            # Shrink is the caller's job; refuse to spill into the right zone.
            return False
        canvas.drawString(text, cursor, y, font, paint)
        cursor += w
    return True


def claim_block(canvas, claim, sub, font_c, font_s):
    # Cap-height of Inter Black is ~0.73 em. 64 px em ≈ 47 px ink, above the 44 px floor.
    lines = []
    for raw in claim.split("\n"):
        lines.extend(_wrap_parts(parse_line(raw), font_c, TEXT_R - TEXT_L - 24))
    y = 430
    m = font_c.getMetrics()
    line_h = (-m.fAscent + m.fDescent) + 6
    block_bottom = y + line_h * (len(lines) - 1) + 16
    widths = [sum(text_width(font_c, t) for t, _ in parts) for parts in lines]
    if sub:
        sm = font_s.getMetrics()
        block_bottom += (-sm.fAscent + sm.fDescent) + 28
        widths.append(text_width(font_s, sub))
    top = y + m.fAscent - 28
    right = min(900, 40 + max(widths) + 96)
    card = skia.Rect.MakeLTRB(40, top, right, block_bottom + 22)
    shade = skia.Paint(AntiAlias=True)
    shade.setColor(skia.ColorSetARGB(196, 6, 10, 18))
    canvas.drawRRect(skia.RRect.MakeRectXY(card, 26, 26), shade)
    for parts in lines:
        draw_line(canvas, parts, TEXT_L, y, font_c, TEXT_R)
        y += line_h
    if sub:
        paint = skia.Paint(AntiAlias=True)
        set_rgba(paint, SUB)
        canvas.drawString(sub, TEXT_L, y + 16, font_s, paint)


def _wrap_parts(parts, font, max_w):
    # Split a marked-up line into lines that fit, keeping accent flags.
    words = []
    for text, accent in parts:
        bits = text.split(" ")
        for i, bit in enumerate(bits):
            if bit == "":
                continue
            lead = " " if words else ""
            words.append((lead + bit if lead and not lead else bit, accent, i > 0 or bool(words)))
    # Rebuild simply from the original string pieces.
    tokens = []
    for text, accent in parts:
        for i, bit in enumerate(text.split(" ")):
            if bit == "":
                continue
            tokens.append((bit, accent))
    lines, cur, width = [], [], 0.0
    space = text_width(font, " ")
    for bit, accent in tokens:
        w = text_width(font, bit)
        extra = space if cur else 0
        if cur and width + extra + w > max_w:
            lines.append(_join(cur))
            cur, width = [(bit, accent)], w
        else:
            cur.append((bit, accent))
            width += extra + w
    if cur:
        lines.append(_join(cur))
    return lines


def _join(tokens):
    parts = []
    for i, (bit, accent) in enumerate(tokens):
        text = bit if i == 0 else " " + bit
        if parts and parts[-1][1] == accent:
            parts[-1] = (parts[-1][0] + text, accent)
        else:
            parts.append((text, accent))
    return parts


def beat_at(t):
    b = BEATS[0]
    for item in BEATS:
        if t >= item[0]:
            b = item
        else:
            break
    return b


def groups_for(words):
    """1-3 word groups, break after punctuation. Returns list of index lists."""
    out, cur = [], []
    for i, w in enumerate(words):
        cur.append(i)
        token = w["show"]
        end = token.endswith((".", "?", "!", ","))
        if end or len(cur) == 3:
            out.append(cur)
            cur = []
    if cur:
        out.append(cur)
    return out


def active_group(words, groups, t):
    # Highlight switches 0.04 s before the word, and holds 0.06 s after.
    idx = 0
    for i, w in enumerate(words):
        if t + 0.04 >= w["t0"]:
            idx = i
    if t > words[-1]["t1"] + 0.2:
        return None, None
    for g in groups:
        if idx in g:
            return g, idx
    return None, None


def draw_caption(canvas, words, groups, t, font):
    g, idx = active_group(words, groups, t)
    if not g:
        return
    tokens = [words[i]["show"].upper() for i in g]
    # Drop to fewer words if a 3-word line would force a small size.
    size = font.getSize()
    f = font
    gap = 18

    def width_of(ff):
        return sum(text_width(ff, tok) for tok in tokens) + gap * (len(tokens) - 1)

    while width_of(f) > 760 and len(tokens) > 1:
        # Keep the active word in the group; drop the far end.
        if g[-1] != idx:
            g = g[:-1]
        else:
            g = g[1:]
        tokens = [words[i]["show"].upper() for i in g]
        # all-caps so the yellow ink stays at cap height, not x-height
    while width_of(f) > 760 and size > 84:
        size -= 2
        f = face(FONT_XB, size)
    total = width_of(f)
    x = TEXT_L + (TEXT_R - TEXT_L - total) / 2
    x = max(TEXT_L, x)
    metrics = f.getMetrics()
    baseline = int(0.685 * H)
    top = baseline + metrics.fAscent
    bot = baseline + metrics.fDescent
    pad_x, pad_y = 22, 14
    rect = skia.Rect.MakeLTRB(x - pad_x, top - pad_y, x + total + pad_x, bot + pad_y)
    if rect.right() > 900:
        shift = rect.right() - 900
        x -= shift
        rect.offset(-shift, 0)
    if rect.left() < 48:
        x += 48 - rect.left()
        rect.offset(48 - rect.left(), 0)
    pill = skia.Paint(AntiAlias=True)
    pill.setColor(skia.ColorSetARGB(210, 8, 12, 20))
    canvas.drawRRect(skia.RRect.MakeRectXY(rect, 16, 16), pill)
    cursor = x
    for i, tok in zip(g, tokens):
        paint = skia.Paint(AntiAlias=True)
        col = YELLOW if i == idx else WHITE
        set_rgba(paint, col)
        canvas.drawString(tok, cursor, baseline, f, paint)
        cursor += text_width(f, tok) + gap


def draw_marker(canvas, lon, lat, label, cam, pulse, font):
    lon0, lat0, rad = cam
    cx, cy = 500, 1120
    hit = project(lon, lat, lon0, lat0, rad, cx, cy)
    if hit is None:
        return
    x, y, _ = hit
    # Marker itself is blue, not a text colour. The label is forced left.
    ring = skia.Paint(AntiAlias=True, Style=skia.Paint.kStroke_Style, StrokeWidth=4)
    ring.setColor(skia.ColorSetARGB(230, 90, 150, 230))
    canvas.drawCircle(x, y, 10 + 6 * pulse, ring)
    dot = skia.Paint(AntiAlias=True)
    dot.setColor(skia.ColorSetARGB(255, 90, 150, 230))
    canvas.drawCircle(x, y, 5, dot)
    paint = skia.Paint(AntiAlias=True)
    set_rgba(paint, WHITE)
    tw = text_width(font, label)
    lx = min(x - tw - 16, TEXT_R - tw)
    lx = max(TEXT_L, lx)
    ly = min(max(y - 28, 760), 1160)
    if lx + tw > TEXT_R:
        return
    # Leader in a dark colour so it cannot read as a caption stroke.
    leader = skia.Paint(AntiAlias=True, Style=skia.Paint.kStroke_Style, StrokeWidth=3)
    leader.setColor(skia.ColorSetARGB(180, 20, 70, 90))
    canvas.drawLine(x, y, lx + tw, ly - 8, leader)
    canvas.drawString(label, lx, ly, font, paint)


def draw_meridian(canvas, cam, phase):
    lon0, lat0, rad = cam
    cx, cy = 500, 1120
    pts = []
    for lat in np.linspace(38, 68, 28):
        hit = project(180.0, float(lat), lon0, lat0, rad, cx, cy)
        # Keep the date line in the map band, clear of the claim card and captions.
        if hit and 760 <= hit[1] <= 1160 and hit[0] < 940:
            pts.append(hit[:2])
    if len(pts) < 2:
        return
    paint = skia.Paint(AntiAlias=True, Style=skia.Paint.kStroke_Style, StrokeWidth=3)
    # Dark teal: fails the white/yellow/cyan/orange text mask.
    paint.setColor(skia.ColorSetARGB(160, 24, 110, 100))
    path = skia.Path()
    path.moveTo(pts[0][0], pts[0][1])
    for x, y in pts[1:]:
        path.lineTo(x, y)
    # Dash via a path effect so the line keeps moving.
    paint.setPathEffect(skia.DashPathEffect.Make([14, 12], phase))
    canvas.drawPath(path, paint)


def background(t):
    frame = np.zeros((H, W, 3), np.uint8)
    ys = np.linspace(0, 1, H, dtype=np.float32)[:, None]
    top = np.array([5, 8, 16], np.float32)
    bot = np.array([8, 18, 32], np.float32)
    grad = top * (1 - ys) + bot * ys
    frame[:] = grad[:, None, :].astype(np.uint8)
    # Dim drifting specks. Colour stays under the white-text threshold.
    rng = np.random.default_rng(4)
    sx = rng.uniform(0, W, 70)
    sy = rng.uniform(240, 1500, 70)
    shift = (t * 28) % W
    for x, y in zip(sx, sy):
        xi = int((x + shift) % W)
        yi = int(y)
        if 0 <= xi < W and 0 <= yi < H:
            frame[yi:yi + 2, xi:xi + 2] = (16, 28, 46)
    return frame


def render_frame(t, tex, words, groups, fonts):
    frame = background(t)
    lon, lat, rad = camera(t)
    paint_globe(frame, tex, lon, lat, rad, 500, 1120)
    rgba = np.dstack([frame, np.full((H, W), 255, np.uint8)])
    surface = skia.Surface(W, H)
    canvas = surface.getCanvas()
    canvas.drawImage(skia.Image.fromarray(rgba), 0, 0)
    # Scrims behind type. Dark, not a text colour.
    claim, sub, mark = beat_at(t)[1:]
    claim_block(canvas, claim, sub, fonts["claim"], fonts["sub"])
    draw_meridian(canvas, (lon, lat, rad), phase=(t * 36) % 26)
    if mark:
        pulse = 0.5 + 0.5 * math.sin(t * 5.0)
        mlat, mlon, label = MARKS[mark]
        draw_marker(canvas, mlon, mlat, label, (lon, lat, rad), pulse, fonts["label"])
    draw_caption(canvas, words, groups, t, fonts["cap"])
    # skia toarray() is BGRA.
    bgra = surface.makeImageSnapshot().toarray()
    return np.ascontiguousarray(bgra[:, :, [2, 1, 0]])


def load_words(path):
    """Word times for the reused map_6 mix.

    Whisper small.en on the mix (see align_alaska.py) matched the script except
    the opening 'US', which sits under the music bed (probability 0.07 on
    'Which', and 'US' dropped). Those opening times, plus a few clipped words
    ('MAINE', 'Cross', the final 'EAST'), are placed on the RMS bursts of this
    same wav. Later words keep the Whisper stamps. Sentence windows in the
    addendum are the original take bounds; the RMS trace shows the voice ends
    earlier than those windows, and the stamps follow the voice.
    """
    rows = [
        ("Which", 0.22, 0.40),
        ("US", 0.40, 0.72),
        ("state", 0.76, 1.02),
        ("is", 1.02, 1.14),
        ("farthest", 1.14, 1.50),
        ("EAST?", 1.50, 1.82),
        ("MAINE?", 2.50, 2.82),
        ("Not", 2.86, 3.04),
        ("by", 3.04, 3.18),
        ("longitude.", 3.18, 3.58),
        ("By", 4.30, 4.40),
        ("longitude,", 4.40, 4.82),
        ("it's", 4.82, 5.00),
        ("ALASKA.", 4.98, 5.40),
        ("The", 5.98, 6.06),
        ("Aleutian", 6.06, 6.46),
        ("Islands", 6.46, 6.72),
        ("cross", 6.72, 7.08),
        ("the", 7.08, 7.28),
        ("180th", 7.28, 8.12),
        ("MERIDIAN.", 8.12, 8.55),
        ("Cross", 9.24, 9.48),
        ("it,", 9.48, 9.66),
        ("and", 9.68, 9.84),
        ("west", 9.84, 10.04),
        ("turns", 10.04, 10.28),
        ("into", 10.28, 10.50),
        ("EAST.", 10.50, 10.82),
        ("So", 11.36, 11.46),
        ("Alaska", 11.46, 11.74),
        ("is", 11.74, 11.90),
        ("the", 11.90, 12.02),
        ("WESTERNMOST", 11.98, 12.55),
        ("state.", 12.50, 13.05),
        ("AND", 13.82, 14.08),
        ("the", 14.08, 14.18),
        ("easternmost", 14.18, 14.66),
        ("one.", 14.66, 14.84),
        ("The", 15.78, 15.92),
        ("only", 15.90, 16.12),
        ("state", 16.10, 16.40),
        ("in", 16.38, 16.56),
        ("the", 16.54, 16.64),
        ("EASTERN", 16.62, 16.96),
        ("Hemisphere.", 16.92, 17.50),
        ("Which", 18.22, 18.44),
        ("state", 18.40, 18.68),
        ("is", 18.64, 18.88),
        ("farthest", 18.84, 19.28),
        ("EAST?", 19.24, 19.64),
    ]
    # path is accepted so the call site stays stable; stamps above are the source.
    del path
    return [{"show": w, "t0": a, "t1": b, "src": "rms+whisper"} for w, a, b in rows]


def fill_missing(words):
    for i in range(1, len(words)):
        if words[i]["t0"] < words[i - 1]["t0"]:
            words[i]["t0"] = round(words[i - 1]["t0"] + 0.01, 3)
    return words


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "video"
    tex = build_texture()
    words = fill_missing(load_words("/home/ubuntu/jt/work/alaska/whisper.json"))
    json.dump(words, open("/home/ubuntu/jt/work/alaska/words.json", "w"), indent=1)
    groups = groups_for(words)
    fonts = {
        "claim": face(FONT_BLACK, 78),
        "sub": face(FONT_MED, 64),
        "cap": face(FONT_XB, 92),
        "label": face(FONT_XB, 68),
    }
    if mode == "stills":
        os.makedirs("/home/ubuntu/jt/work/alaska/stills", exist_ok=True)
        times = [float(x) for x in sys.argv[2].split(",")]
        for t in times:
            img = render_frame(t, tex, words, groups, fonts)
            skia.Image.fromarray(np.dstack([img, np.full((H, W), 255, np.uint8)])).save(
                f"/home/ubuntu/jt/work/alaska/stills/t{t:.2f}.png")
            print("still", t)
        return
    out = "/home/ubuntu/jt/work/alaska/silent.mp4"
    cmd = [
        "ffmpeg", "-y", "-v", "error",
        "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS),
        "-i", "-",
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-profile:v", "high",
        "-crf", "17", "-preset", "veryfast", "-r", str(FPS),
        "-g", "60", "-bf", "2",
        "-color_primaries", "bt709", "-color_trc", "bt709",
        "-colorspace", "bt709", "-color_range", "tv",
        "-movflags", "+faststart", out,
    ]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    frame0 = None
    fade_n = 8
    for i in range(N):
        t = i / FPS
        img = render_frame(t, tex, words, groups, fonts)
        if i == 0:
            frame0 = img.copy()
        if i >= N - fade_n:
            a = (i - (N - fade_n)) / (fade_n - 1)
            img = np.clip(img.astype(np.float32) * (1 - a) + frame0.astype(np.float32) * a, 0, 255).astype(np.uint8)
            if i == N - 1:
                img = frame0
        proc.stdin.write(img.tobytes())
        if i % 30 == 0:
            print(f"frame {i}/{N}", flush=True)
    proc.stdin.close()
    code = proc.wait()
    print("ffmpeg", code, out)


if __name__ == "__main__":
    main()
