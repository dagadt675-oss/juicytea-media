"""Natural Earth globe texture. Public-domain admin-0 polygons, rasterized once."""
import os
import numpy as np
import shapefile
import skia

NE10 = "/home/ubuntu/jt/ne/10m/ne_10m_admin_0_countries.shp"
CACHE = "/home/ubuntu/jt/work/earth_tex_v1.npy"

# Not white / yellow / cyan / orange, so the safe-zone pixel check
# does not treat land fills as captions.
USA = (47, 107, 214, 255)
CAN = (28, 78, 96, 255)
RUS = (92, 58, 62, 255)
LAND = (24, 58, 52, 255)


def _paint(rgba):
    r, g, b, a = rgba
    p = skia.Paint(AntiAlias=False)
    p.setColor(skia.ColorSetARGB(a, r, g, b))
    p.setStyle(skia.Paint.kFill_Style)
    return p


def _draw_ring(canvas, lons, lats, W, H, paint):
    lons = np.asarray(lons, np.float64)
    lats = np.asarray(lats, np.float64)
    if len(lons) < 4:
        return
    cuts = [0]
    for i in range(1, len(lons)):
        if abs(lons[i] - lons[i - 1]) > 180:
            cuts.append(i)
    cuts.append(len(lons))
    for a, b in zip(cuts, cuts[1:]):
        if b - a < 4:
            continue
        xs = (lons[a:b] + 180.0) / 360.0 * W
        ys = (90.0 - lats[a:b]) / 180.0 * H
        path = skia.Path()
        path.moveTo(float(xs[0]), float(ys[0]))
        for x, y in zip(xs[1:], ys[1:]):
            path.lineTo(float(x), float(y))
        path.close()
        canvas.drawPath(path, paint)


def build_texture(W=6144, H=3072):
    if os.path.exists(CACHE):
        tex = np.load(CACHE)
        if tex.shape == (H, W, 4):
            return tex
    paints = {
        "USA": _paint(USA),
        "CAN": _paint(CAN),
        "RUS": _paint(RUS),
    }
    land = _paint(LAND)
    surface = skia.Surface(W, H)
    canvas = surface.getCanvas()
    canvas.clear(skia.ColorSetARGB(0, 0, 0, 0))
    reader = shapefile.Reader(NE10)
    # Two passes: all land, then highlighted countries on top.
    records = list(reader.iterShapeRecords())
    for highlight in (False, True):
        for sr in records:
            iso = sr.record["ADM0_A3"]
            if highlight and iso not in paints:
                continue
            if not highlight and iso in paints:
                continue
            paint = paints.get(iso, land)
            shape = sr.shape
            if not shape.points:
                continue
            pts = np.asarray(shape.points, np.float64)
            parts = list(shape.parts) + [len(pts)]
            for i in range(len(parts) - 1):
                ring = pts[parts[i]:parts[i + 1]]
                _draw_ring(canvas, ring[:, 0], ring[:, 1], W, H, paint)
    # skia toarray() is BGRA. Store straight RGBA.
    bgra = surface.makeImageSnapshot().toarray()
    tex = np.ascontiguousarray(bgra[:, :, [2, 1, 0, 3]])
    np.save(CACHE, tex)
    return tex


def paint_globe(frame, tex, lon0, lat0, r, cx, cy):
    """Orthographic sample of `tex` into RGB uint8 `frame`."""
    H, W = frame.shape[:2]
    th, tw = tex.shape[:2]
    x0 = max(0, int(cx - r))
    x1 = min(W, int(np.ceil(cx + r)) + 1)
    y0 = max(0, int(cy - r))
    y1 = min(H, int(np.ceil(cy + r)) + 1)
    if x1 <= x0 or y1 <= y0:
        return
    yy, xx = np.mgrid[y0:y1, x0:x1]
    nx = (xx - cx) / r
    ny = (cy - yy) / r
    rho2 = nx * nx + ny * ny
    m = rho2 <= 1.0
    if not np.any(m):
        return
    nz = np.zeros(nx.shape, np.float32)
    nz[m] = np.sqrt(1.0 - rho2[m]).astype(np.float32)
    lat0r = np.float32(np.radians(lat0))
    lon0r = np.float32(np.radians(lon0))
    sl, cl = np.sin(lat0r), np.cos(lat0r)
    nxm = nx[m].astype(np.float32)
    nym = ny[m].astype(np.float32)
    nzm = nz[m]
    lat = np.arcsin(np.clip(nzm * sl + nym * cl, -1, 1))
    lon = lon0r + np.arctan2(nxm, nzm * cl - nym * sl)
    xf = (np.degrees(lon) + 180.0) / 360.0 * tw
    yf = (90.0 - np.degrees(lat)) / 180.0 * th
    xf = np.mod(xf, tw)
    yf = np.clip(yf, 0, th - 1.001)
    xi0 = np.floor(xf).astype(np.int32) % tw
    yi0 = np.floor(yf).astype(np.int32)
    xi1 = (xi0 + 1) % tw
    yi1 = np.minimum(yi0 + 1, th - 1)
    fx = (xf - np.floor(xf)).astype(np.float32)[:, None]
    fy = (yf - np.floor(yf)).astype(np.float32)[:, None]
    c00 = tex[yi0, xi0].astype(np.float32)
    c10 = tex[yi0, xi1].astype(np.float32)
    c01 = tex[yi1, xi0].astype(np.float32)
    c11 = tex[yi1, xi1].astype(np.float32)
    c = (c00 * (1 - fx) * (1 - fy) + c10 * fx * (1 - fy)
         + c01 * (1 - fx) * fy + c11 * fx * fy)
    alpha = c[:, 3:4] / 255.0
    light = np.clip(nzm * 0.82 + nym * 0.28 - nxm * 0.12, 0, 1)[:, None]
    shade = 0.42 + 0.58 * light
    ocean = np.array([7, 27, 48], np.float32)
    col = (ocean * (1 - alpha) + c[:, :3] * alpha) * shade
    rim = np.clip(1 - nzm, 0, 1)[:, None] ** 1.7
    # Rim is blue-grey, not cyan (cyan trips the text detector).
    col = col * (1 - 0.35 * rim) + np.array([70, 110, 140], np.float32) * rim * 0.28
    sub = frame[y0:y1, x0:x1]
    sub[m] = np.clip(col, 0, 255).astype(np.uint8)


def project(lon, lat, lon0, lat0, r, cx, cy):
    latr, lonr = np.radians(lat), np.radians(lon)
    lat0r, lon0r = np.radians(lat0), np.radians(lon0)
    cosc = (np.sin(lat0r) * np.sin(latr)
            + np.cos(lat0r) * np.cos(latr) * np.cos(lonr - lon0r))
    if cosc <= 0.05:
        return None
    x = np.cos(latr) * np.sin(lonr - lon0r)
    y = (np.cos(lat0r) * np.sin(latr)
         - np.sin(lat0r) * np.cos(latr) * np.cos(lonr - lon0r))
    return float(cx + r * x), float(cy - r * y), float(cosc)
