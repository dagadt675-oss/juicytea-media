# Juicy Tea gyártósor

Egy szkriptből készül a videó. A családok csak a képben térnek el: térkép, mítosz, kvíz, what-if. A Reddit-voxel nem fő stílus.

## Mit csinál

1. Szóidő (Whisper a keveréken, vagy a szkriptben megadott idő).
2. Karaoke: 1–3 szó, NAGYBETŰ, a kimondott szó sárga, x ≤ 880.
3. Render szegmens nélkül, képkockánként, a safe zone a rajzolóban van.
4. Hang: a meglévő keverék, a kulcsszó végén +6 dB a lehalkított mixhez képest.
5. Loudnorm, cél −14 LUFS, TP −3,0 a wav-on. AAC 320 kbps: a 192 kbps ezen a gépen −0,2 dBFS-re vitte a csúcsot.
6. H.264, bt709, AAC 48 kHz, az utolsó képkocka = az első.
7. QC-számok és review-csomag.

## Parancs

```bash
/home/ubuntu/jt-venv/bin/python render_alaska.py stills 0.5,5.1,14.5
/home/ubuntu/jt-venv/bin/python render_alaska.py video
```

A Natural Earth 10m shapefile a `/home/ubuntu/jt/ne/10m/` alatt kell. A textúra cache: `/home/ubuntu/jt/work/earth_tex_v1.npy`.

Hang és kép nem kerül ebbe a mappába. Kulcs sem.

## Review

Amint egy videó kész, a csomag a Project tároló `internal/review-inbox/<név>/` mappájába megy, és a szülő ugyanabban a körben megkapja. 8/10 alatt nincs ütemezés. A szülő egy javítólistát ad, azt egy menetben kell megcsinálni.
