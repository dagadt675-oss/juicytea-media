import json
import numpy as np
import soundfile as sf
from math import gcd
from scipy.signal import resample_poly
from faster_whisper import WhisperModel
wav = "/home/ubuntu/jt/work/alaska/src.wav"
audio, sr = sf.read(wav, dtype="float32")
if audio.ndim == 2:
    audio = audio.mean(axis=1)
g = gcd(16000, sr)
audio16 = resample_poly(audio, 16000 // g, sr // g).astype(np.float32)
model = WhisperModel("small.en", device="cpu", compute_type="int8", download_root="/home/ubuntu/jt/work/hf")
segs, info = model.transcribe(
    audio16, word_timestamps=True, language="en", vad_filter=False,
    initial_prompt=("Which US state is farthest east? Maine? Not by longitude. "
                    "By longitude, it's Alaska. The Aleutian Islands cross the 180th meridian. "
                    "Cross it, and west turns into east. So Alaska is the westernmost state. "
                    "And the easternmost one. The only state in the eastern hemisphere. "
                    "Which state is farthest east?"),
    condition_on_previous_text=False,
)
words = []
for s in segs:
    if not s.words:
        continue
    for w in s.words:
        words.append({"w": w.word.strip(), "t0": round(w.start, 3), "t1": round(w.end, 3), "p": round(w.probability, 3)})
json.dump({"words": words, "lang": info.language, "dur": info.duration}, open("/home/ubuntu/jt/work/alaska/whisper.json","w"), indent=1)
print(len(words), "words")
print(" ".join(x["w"] for x in words))
