import bpy

from .neatify import ny_table, ny_box
from .groups import (
    b_wide_base,
    b_wide_base_layer,
    s_colored_shadow,
    s_realistic,
    t_cloud,
)

bl_info = {
    "name": "Easy Clouds",
    "author": "LunarKitten",
    "version": (2, 2, 0),
    "blender": (4, 3, 2),
    "location": "View3d > Tool",
    "warning": "",
    "wiki_url": "https://codeberg.org/LunarKitten/EasyClouds",
    "category": "Add Mesh, Material, Shader Group, Clouds",
}


# Side Panel Buttons
class EC_Panel(bpy.types.Panel):
    bl_label = "Easy Clouds"
    bl_idname = "EASYCLOUDS_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"

    def draw(self, context):
        layout = self.layout

        row = layout.row()
        row.label(text="Use edit mode to show more/less of the clouds", icon="INFO")

        row = layout.row()
        row.operator("easyclouds.create_cloud")

        row = layout.row()
        row.operator("easyclouds.create_sphere")

        row = layout.row()
        row.operator("easyclouds.create_layer")


# The shader outputs of both cloud layer and cloud are the same so I moved them to this function
def cloud_shader_standard(node_tree, cnt):
    return ny_table.new(
        node_tree,
        {
            "Realistic Cloud Volume": {
                "data": cnt.new("ShaderNodeGroup"),
                "properties": {
                    "node tree": bpy.data.node_groups[s_realistic.get_name()]
                },
                "links": [
                    [0, "Cycles", 1],
                ],
            },
            "Colored Shadow Volume": {
                "data": cnt.new("ShaderNodeGroup"),
                "properties": {
                    "node tree": bpy.data.node_groups[s_colored_shadow.get_name()]
                },
                "links": [
                    [0, "EEVEE", 1],
                ],
            },
            "column 2": {"data": "new_column"},
            "Cycles": {
                "data": cnt.new("ShaderNodeOutputMaterial"),
                "properties": {
                    "target": "CYCLES",
                },
            },
            "EEVEE": {
                "data": cnt.new("ShaderNodeOutputMaterial"),
                "properties": {
                    "target": "EEVEE",
                },
            },
        },
    )


class EC_CreateCloud(bpy.types.Operator):
    bl_label = "Create Cloud"
    bl_idname = "easyclouds.create_cloud"
    bl_description = "Create a new cloud with defaults applied"

    def execute(self, context):
        material = bpy.data.materials.new(name="EC Cloud")
        material.use_nodes = True
        cnt = material.node_tree.nodes
        # Remove default nodes
        cnt.remove(cnt.get("Principled BSDF"))
        cnt.remove(cnt.get("Material Output"))

        shape = ny_table.new(
            material.node_tree,
            {
                "Mapping": {
                    "data": cnt.new("ShaderNodeMapping"),
                    "height": 360,
                    "links": [
                        [0, "Voronoi", 0],
                    ],
                },
                "column": {"data": "new_column"},
                "Voronoi": {
                    "data": cnt.new("ShaderNodeTexVoronoi"),
                    "height": 340,
                    "properties": {
                        "normalize": True,
                        "2": 4.4,
                        "3": 4.2,
                        "4": 0.4,
                        "5": 3,
                    },
                    "links": [
                        [0, "Map Range", 0],
                    ],
                },
                "column 2": {"data": "new_column"},
                "Map Range": {
                    "data": cnt.new("ShaderNodeMapRange"),
                    "height": 240,
                    "properties": {
                        "3": 1,
                        "4": 0,
                    },
                },
            },
        )

        detail = ny_table.new(
            material.node_tree,
            {
                "Mapping Detail": {
                    "data": cnt.new("ShaderNodeMapping"),
                    "height": 360,
                    "links": [
                        [0, "Detail", 0],
                    ],
                },
                "Mapping Exclusion": {
                    "data": cnt.new("ShaderNodeMapping"),
                    "height": 360,
                    "links": [
                        [0, "Exclusion", 0],
                    ],
                },
                "column": {"data": "new_column"},
                "Detail": {
                    "data": cnt.new("ShaderNodeTexNoise"),
                    "height": 300,
                    "properties": {
                        "2": 15,
                        "3": 6,
                        "4": 0.64,
                        "5": 2.8,
                        "8": 1.6,
                    },
                    "links": [
                        [0, "Map Range Detail", 0],
                    ],
                },
                "Exclusion": {
                    "data": cnt.new("ShaderNodeTexNoise"),
                    "height": 300,
                    "properties": {
                        "2": 6.4,
                        "8": 1,
                    },
                    "links": [
                        [0, "Map Range Exclusion", 0],
                    ],
                },
                "column 2": {"data": "new_column"},
                "Map Range Detail": {
                    "data": cnt.new("ShaderNodeMapRange"),
                    "height": 240,
                    "properties": {
                        "1": 0.55,
                        "2": 0.62,
                    },
                    "links": [
                        [0, "Multiply", 0],
                    ],
                },
                "Map Range Exclusion": {
                    "data": cnt.new("ShaderNodeMapRange"),
                    "height": 240,
                    "properties": {
                        "1": 0.2,
                        "2": 0.8,
                    },
                    "links": [
                        [0, "Multiply", 1],
                    ],
                },
                "column 3": {"data": "new_column"},
                "Multiply": {
                    "data": cnt.new("ShaderNodeMath"),
                    "properties": {
                        "operation": "MULTIPLY",
                    },
                },
            },
        )

        ny_table.new(
            material.node_tree,
            {
                "Tex Coord": {
                    "data": cnt.new("ShaderNodeTexCoord"),
                    "links": [
                        [0, "Bounding", 0],
                        [3, ["Shape", "Mapping"], 0],
                        [3, ["Detail", "Mapping Detail"], 0],
                        [3, ["Detail", "Mapping Exclusion"], 0],
                    ],
                },
                "column": {"data": "new_column"},
                "Bounding": {
                    "data": cnt.new("ShaderNodeGroup"),
                    "properties": {
                        "node tree": bpy.data.node_groups[b_wide_base.get_name()],
                        "1": 0.15,
                        "2": 0.95,
                        "3": 0.65,
                    },
                    "links": [[0, "Combine Maps", 0]],
                },
                "Shape": {
                    "data": shape,
                    "links": [["Map Range", 0, "Combine Maps", 1]],
                },
                "Detail": {
                    "data": detail,
                    "links": [["Multiply", 0, "Combine Maps", 3]],
                },
                "column 2": {"data": "new_column"},
                "Combine Maps": {
                    "data": cnt.new("ShaderNodeGroup"),
                    "height": 200,
                    "properties": {
                        "node tree": bpy.data.node_groups[t_cloud.get_name()],
                        "2": 0.41,
                        "4": 0.19,
                        "5": 0.02,
                    },
                    "links": [
                        [0, ["Shader", "Realistic Cloud Volume"], 1],
                        [0, ["Shader", "Colored Shadow Volume"], 2],
                    ],
                },
                "column 3": {"data": "new_column"},
                "Shader": {
                    "data": cloud_shader_standard(material.node_tree, cnt),
                },
            },
        )

        object = ny_box.new(1, 1.5, 0.8)
        object.active_material = material

        return {"FINISHED"}


class EC_CreateCloudLayer(bpy.types.Operator):
    bl_label = "Create Layer"
    bl_idname = "easyclouds.create_layer"
    bl_description = "Create a new layer with defaults applied"

    def execute(self, context):
        material = bpy.data.materials.new(name="EC Cloud Layer")
        material.use_nodes = True
        cnt = material.node_tree.nodes
        # Remove default nodes
        cnt.remove(cnt.get("Principled BSDF"))
        cnt.remove(cnt.get("Material Output"))

        shape = ny_table.new(
            material.node_tree,
            {
                "Mapping": {
                    "data": cnt.new("ShaderNodeMapping"),
                    "height": 360,
                    "links": [
                        [0, "Voronoi", 0],
                    ],
                },
                "column": {"data": "new_column"},
                "Voronoi": {
                    "data": cnt.new("ShaderNodeTexVoronoi"),
                    "height": 340,
                    "properties": {
                        "normalize": True,
                        "2": 1.1,
                        "3": 3,
                        "4": 0.38,
                        "5": 4.2,
                        "8": 0.8,
                    },
                    "links": [
                        [0, "Map Range", 0],
                    ],
                },
                "column 2": {"data": "new_column"},
                "Map Range": {
                    "data": cnt.new("ShaderNodeMapRange"),
                    "height": 240,
                    "properties": {
                        "1": 0.04,
                        "3": 1,
                        "4": 0,
                    },
                },
            },
        )

        detail = ny_table.new(
            material.node_tree,
            {
                "Mapping Detail": {
                    "data": cnt.new("ShaderNodeMapping"),
                    "height": 360,
                    "links": [
                        [0, "Detail", 0],
                    ],
                },
                "Mapping Exclusion": {
                    "data": cnt.new("ShaderNodeMapping"),
                    "height": 360,
                    "links": [
                        [0, "Exclusion", 0],
                    ],
                },
                "column": {"data": "new_column"},
                "Detail": {
                    "data": cnt.new("ShaderNodeTexNoise"),
                    "height": 300,
                    "properties": {
                        "2": 3,
                        "4": 1,
                        "8": 3,
                    },
                    "links": [
                        [0, "Map Range Detail", 0],
                    ],
                },
                "Exclusion": {
                    "data": cnt.new("ShaderNodeTexNoise"),
                    "height": 300,
                    "properties": {
                        "2": 2.38,
                    },
                    "links": [
                        [0, "Map Range Exclusion", 0],
                    ],
                },
                "column 2": {"data": "new_column"},
                "Map Range Detail": {
                    "data": cnt.new("ShaderNodeMapRange"),
                    "height": 240,
                    "properties": {
                        "1": 0.45,
                        "2": 0.5,
                    },
                    "links": [
                        [0, "Multiply", 0],
                    ],
                },
                "Map Range Exclusion": {
                    "data": cnt.new("ShaderNodeMapRange"),
                    "height": 240,
                    "properties": {
                        "1": 0.5,
                        "2": 0.6,
                    },
                    "links": [
                        [0, "Multiply", 1],
                    ],
                },
                "column 3": {"data": "new_column"},
                "Multiply": {
                    "data": cnt.new("ShaderNodeMath"),
                    "properties": {
                        "operation": "MULTIPLY",
                    },
                },
            },
        )

        ny_table.new(
            material.node_tree,
            {
                "Tex Coord": {
                    "data": cnt.new("ShaderNodeTexCoord"),
                    "links": [
                        [0, "Bounding (layer)", 0],
                        [3, ["Shape", "Mapping"], 0],
                        [3, ["Detail", "Mapping Detail"], 0],
                        [3, ["Detail", "Mapping Exclusion"], 0],
                    ],
                },
                "column": {"data": "new_column"},
                "Bounding (layer)": {
                    "data": cnt.new("ShaderNodeGroup"),
                    "properties": {
                        "node tree": bpy.data.node_groups[b_wide_base_layer.get_name()],
                        "2": 0.32,
                    },
                    "links": [[0, "Combine Maps", 0]],
                },
                "Shape": {
                    "data": shape,
                    "links": [["Map Range", 0, "Combine Maps", 1]],
                },
                "Detail": {
                    "data": detail,
                    "links": [["Multiply", 0, "Combine Maps", 3]],
                },
                "column 2": {"data": "new_column"},
                "Combine Maps": {
                    "data": cnt.new("ShaderNodeGroup"),
                    "height": 200,
                    "properties": {
                        "node tree": bpy.data.node_groups[t_cloud.get_name()],
                        "2": 0.78,
                        "4": 0.6,
                        "5": 0.06,
                    },
                    "links": [
                        [0, ["Shader", "Realistic Cloud Volume"], 1],
                        [0, ["Shader", "Colored Shadow Volume"], 2],
                    ],
                },
                "column 3": {"data": "new_column"},
                "Shader": {
                    "data": cloud_shader_standard(material.node_tree, cnt),
                },
            },
        )

        object = ny_box.new(10, 10, 1)
        object.active_material = material

        return {"FINISHED"}


class EC_CreateCloudSphere(bpy.types.Operator):
    bl_label = "Create Sphere"
    bl_idname = "easyclouds.create_sphere"
    bl_description = (
        "Create a new spherical cloud, used to manually create/modify cloud shapes"
    )

    def execute(self, context):
        material = bpy.data.materials.new(name="EC Sphere")
        material.use_nodes = True
        cnt = material.node_tree.nodes
        # Remove default nodes
        cnt.remove(cnt.get("Principled BSDF"))
        cnt.remove(cnt.get("Material Output"))

        bounding = ny_table.new(
            material.node_tree,
            {
                "Gradient": {
                    "data": cnt.new("ShaderNodeTexGradient"),
                    "properties": {
                        "gradient type": "SPHERICAL",
                    },
                    "links": [
                        [1, "Power", 0],
                    ],
                },
                "column": {"data": "new_column"},
                "Power": {
                    "data": cnt.new("ShaderNodeMath"),
                    "properties": {
                        "operation": "POWER",
                        "1": 0.3,
                    },
                    "links": [
                        [0, "Map Range", 0],
                    ],
                },
                "column 2": {"data": "new_column"},
                "Map Range": {
                    "data": cnt.new("ShaderNodeMapRange"),
                    "height": 240,
                },
            },
        )

        shape = ny_table.new(
            material.node_tree,
            {
                "Mapping": {
                    "data": cnt.new("ShaderNodeMapping"),
                    "height": 360,
                    "links": [
                        [0, "Voronoi", 0],
                    ],
                },
                "column": {"data": "new_column"},
                "Voronoi": {
                    "data": cnt.new("ShaderNodeTexVoronoi"),
                    "height": 340,
                    "properties": {
                        "normalize": True,
                        "2": 1.8, 
                        "3": 5,
                        "4": 0.4,
                        "5": 2.2,
                    },
                    "links": [
                        [0, "Map Range", 0],
                    ],
                },
                "column 2": {"data": "new_column"},
                "Map Range": {
                    "data": cnt.new("ShaderNodeMapRange"),
                    "height": 240,
                    "properties": {
                        "3": 1,
                        "4": 0,
                    },
                },
            },
        )

        detail = ny_table.new(
            material.node_tree,
            {
                "Mapping Detail": {
                    "data": cnt.new("ShaderNodeMapping"),
                    "height": 360,
                    "links": [
                        [0, "Detail", 0],
                    ],
                },
                "Mapping Exclusion": {
                    "data": cnt.new("ShaderNodeMapping"),
                    "height": 360,
                    "links": [
                        [0, "Exclusion", 0],
                    ],
                },
                "column": {"data": "new_column"},
                "Detail": {
                    "data": cnt.new("ShaderNodeTexNoise"),
                    "height": 300,
                    "properties": {
                        "2": 2,
                        "3": 6,
                        "4": 0.64,
                        "5": 2.8,
                        "8": 1.6,
                    },
                    "links": [
                        [0, "Map Range Detail", 0],
                    ],
                },
                "Exclusion": {
                    "data": cnt.new("ShaderNodeTexNoise"),
                    "height": 300,
                    "properties": {
                        "2": 3,
                        "8": 1,
                    },
                    "links": [
                        [0, "Map Range Exclusion", 0],
                    ],
                },
                "column 2": {"data": "new_column"},
                "Map Range Detail": {
                    "data": cnt.new("ShaderNodeMapRange"),
                    "height": 240,
                    "properties": {
                        "1": 0.5,
                    },
                    "links": [
                        [0, "Multiply", 0],
                    ],
                },
                "Map Range Exclusion": {
                    "data": cnt.new("ShaderNodeMapRange"),
                    "height": 240,
                    "properties": {
                        "1": 0.2,
                        "2": 0.8,
                    },
                    "links": [
                        [0, "Multiply", 1],
                    ],
                },
                "column 3": {"data": "new_column"},
                "Multiply": {
                    "data": cnt.new("ShaderNodeMath"),
                    "properties": {
                        "operation": "MULTIPLY",
                    },
                },
            },
        )

        ny_table.new(
            material.node_tree,
            {
                "Tex Coord": {
                    "data": cnt.new("ShaderNodeTexCoord"),
                    "links": [
                        [3, ["Bounding", "Gradient"], 0],
                        [3, ["Shape", "Mapping"], 0],
                        [3, ["Detail", "Mapping Detail"], 0],
                        [3, ["Detail", "Mapping Exclusion"], 0],
                    ],
                },
                "column": {"data": "new_column"},
                "Bounding": {
                    "data": bounding,
                    "links": [["Map Range", 0, "Combine Maps", 0]],
                },
                "Shape": {
                    "data": shape,
                    "links": [["Map Range", 0, "Combine Maps", 1]],
                },
                "Detail": {
                    "data": detail,
                    "links": [["Multiply", 0, "Combine Maps", 3]],
                },
                "column 2": {"data": "new_column"},
                "Combine Maps": {
                    "data": cnt.new("ShaderNodeGroup"),
                    "height": 200,
                    "properties": {
                        "node tree": bpy.data.node_groups[t_cloud.get_name()],
                        "2": 0.52,
                        "4": 0.015,
                        "5": 0.02,
                    },
                    "links": [
                        [0, ["Shader", "Realistic Cloud Volume"], 1],
                        [0, ["Shader", "Colored Shadow Volume"], 2],
                    ],
                },
                "column 3": {"data": "new_column"},
                "Shader": {
                    "data": cloud_shader_standard(material.node_tree, cnt),
                },
            },
        )

        object = ny_box.new(1.8, 1.8, 1.8)
        object.active_material = material

        return {"FINISHED"}


# Register Unregister
classes = [EC_Panel, EC_CreateCloud, EC_CreateCloudLayer, EC_CreateCloudSphere]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
