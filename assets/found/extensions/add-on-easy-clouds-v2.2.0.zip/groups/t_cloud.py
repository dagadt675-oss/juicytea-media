import bpy
from ..neatify import ny_group, ny_table


def get_name():
    group = ny_group.new(
        "EC Combine Maps",
        [
            {
                "name": "Bounding Map",
                "hidden": True,
            },
            {
                "name": "Shape Texture",
                "hidden": True,
            },
            {
                "name": "Shape Size",
                "value": 1,
            },
            {
                "name": "Detail Texture",
                "hidden": True,
            },
            {
                "name": "Detail Threshold",
                "value": 0.05,
                "min": 0,
                "max": 1,
                "subtype": "FACTOR",
            },
            {
                "name": "Detail End",
                "value": 0.05,
            },
        ],
        [{"name": "Fac"}],
    )

    cnt = group.nodes

    detail_mix = ny_table.new(
        group,
        {
            "Map Range": {
                "data": cnt.new("ShaderNodeMapRange"),
                "height": 220,
                "links": [
                    [0, "Less Than", 0],
                    [0, "Multiply", 1],
                ],
            },
            "column": {"data": "new_column"},
            "Less Than": {
                "data": cnt.new("ShaderNodeMath"),
                "height": 300,
                "properties": {
                    "operation": "LESS_THAN",
                    "clamp": True,
                    "1": 1,
                },
                "links": [
                    [0, "Multiply", 0],
                ],
            },
            "column 2": {"data": "new_column"},
            "Multiply": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "MULTIPLY",
                    "clamp": True,
                },
                "links": [
                    [0, "Multiply Detail", 0],
                ],
            },
            "column 3": {"data": "new_column"},
            "Multiply Detail": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "MULTIPLY",
                },
                "links": [
                    [0, "Greater Than", 0],
                ],
            },
            "column 4": {"data": "new_column"},
            "Greater Than": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "GREATER_THAN",
                    "clamp": True,
                },
            },
        },
    )

    ny_table.new(
        group,
        {
            "in": {
                "data": cnt.new("NodeGroupInput"),
                "links": [
                    [0, "Multiply", 0],
                    [1, "Multiply", 1],
                    [2, ["Detail Mix", "Map Range"], 2],
                    [2, "Subtract", 0],
                    [2, "Greater Than", 1],
                    [3, ["Detail Mix", "Multiply Detail"], 1],
                    [4, ["Detail Mix", "Greater Than"], 1],
                    [5, "Subtract", 1],
                ],
            },
            "column": {"data": "new_column"},
            "Multiply": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "MULTIPLY",
                },
                "links": [
                    [0, ["Detail Mix", "Map Range"], 0],
                    [0, "Greater Than", 0],
                ],
            },
            "Subtract": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "SUBTRACT",
                },
                "links": [
                    [0, ["Detail Mix", "Map Range"], 1],
                ],
            },
            "column 2": {"data": "new_column"},
            "Detail Mix": {
                "data": detail_mix,
                "links": [
                    ["Greater Than", 0, "Add", 0],
                ],
            },
            "Greater Than": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "GREATER_THAN",
                },
                "links": [
                    [0, "Add", 1],
                ],
            },
            "column 3": {"data": "new_column"},
            "Add": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "ADD",
                    "clamp": True,
                },
                "links": [
                    [0, "out", 0],
                ],
            },
            "column 4": {"data": "new_column"},
            "out": {
                "data": cnt.new("NodeGroupOutput"),
            },
        },
    )

    return group.name
