import bpy
from ..neatify import ny_group, ny_table


def get_name():
    group = ny_group.new(
        "EC Realistic Cloud Volume",
        [
            {
                "name": "Color",
                "type": "NodeSocketColor",
                "value": (1, 1, 1, 1),
            },
            {
                "name": "Texture",
                "hidden": True,
            },
            {
                "name": "Density",
                "value": 200,
                "min": 0,
            },
        ],
        [
            {
                "name": "Volume",
                "type": "NodeSocketShader",
            },
        ],
    )

    cnt = group.nodes

    ray_depth = ny_table.new(
        group,
        {
            "Light Paths": {
                "data": cnt.new("ShaderNodeLightPath"),
                "height": 300,
                "links": [
                    [8, "Power", 1],
                    [8, "Add", 0],
                ],
            },
            "column": {"data": "new column"},
            "Power": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "POWER",
                    "0": 0.54,
                },
            },
            "Add": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "1": 1,
                },
                "links": [
                    [0, "Power 2", 1],
                ],
            },
            "column 2": {"data": "new column"},
            "Power 2": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "POWER",
                    "0": 0.9,
                },
            },
        },
    )

    gamma_math = ny_table.new(
        group,
        {
            "Gamma": {
                "data": cnt.new("ShaderNodeGamma"),
                "height": 160,
                "links": [
                    [0, "Density Multiplied", 0],
                ],
            },
            "column": {"data": "new column"},
            "Density Multiplied": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "MULTIPLY",
                },
                "links": [
                    [0, "Ray Depth Multiplied", 0],
                ],
            },
            "column 2": {"data": "new column"},
            "Ray Depth Multiplied": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "MULTIPLY",
                },
            },
        },
    )

    ny_table.new(
        group,
        {
            "in": {
                "data": cnt.new("NodeGroupInput"),
                "links": [
                    [0, "Volume Scatter", 0],
                    [1, ["Gamma Math", "Gamma"], 0],
                    [2, ["Gamma Math", "Density Multiplied"], 1],
                ],
            },
            "column": {"data": "new column"},
            "Gamma Math": {
                "data": gamma_math,
                "links": [
                    ["Ray Depth Multiplied", 0, "Volume Scatter", 1],
                ],
            },
            "Ray Depth Math": {
                "data": ray_depth,
                "links": [
                    ["Power", 0, ["Gamma Math", "Ray Depth Multiplied"], 1],
                    ["Power 2", 0, "Volume Scatter", 2],
                ],
            },
            "column 2": {"data": "new column"},
            "Volume Scatter": {
                "data": cnt.new("ShaderNodeVolumeScatter"),
                "links": [
                    [0, "out", 0],
                ],
            },
            "column 3": {"data": "new column"},
            "out": {
                "data": cnt.new("NodeGroupOutput"),
            },
        },
    )

    return group.name
