import bpy
from ..neatify import ny_group, ny_table


def get_name():
    group = ny_group.new(
        "EC Wide Base Layer Bounding",
        [
            {
                "name": "Vector",
                "type": "NodeSocketVector",
                "hidden": True,
            },
            {
                "name": "Z Mid",
                "value": 0.2,
                "min": 0,
                "max": 1,
                "subtype": "FACTOR",
            },
            {
                "name": "Z Power",
                "value": 1,
                "min": 0,
            },
            {
                "name": "XY Power",
                "value": 1,
                "min": 0,
            },
        ],
        [{"name": "Fac"}],
    )

    cnt = group.nodes

    xy = ny_table.new(
        group,
        {
            "PingPong X": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "PINGPONG",
                    "clamp": True,
                    "1": 0.5,
                },
                "links": [
                    [0, "Multiply", 0],
                ],
            },
            "PingPong Y": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "PINGPONG",
                    "clamp": True,
                    "1": 0.5,
                },
                "links": [
                    [0, "Multiply", 1],
                ],
            },
            "column": {"data": "new column"},
            "Multiply": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "MULTIPLY",
                    "clamp": True,
                },
                "links": [
                    [0, "Map Range", 0],
                ],
            },
            "column 2": {"data": "new column"},
            "Map Range": {
                "data": cnt.new("ShaderNodeMapRange"),
                "height": 220,
                "properties": {
                    "2": 0.05,
                },
                "links": [
                    [0, "Power", 0],
                ],
            },
            "column 3": {"data": "new column"},
            "Power": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "POWER",
                    "clamp": True,
                },
            },
        },
    )

    z = ny_table.new(
        group,
        {
            "Map Range": {
                "data": cnt.new("ShaderNodeMapRange"),
                "height": 220,
                "links": [
                    [0, "Multiply", 0],
                ],
            },
            "Map Range 2": {
                "data": cnt.new("ShaderNodeMapRange"),
                "height": 220,
                "properties": {
                    "1": 1,
                },
                "links": [
                    [0, "Multiply", 1],
                ],
            },
            "column": {"data": "new column"},
            "Multiply": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "MULTIPLY",
                    "clamp": True,
                },
                "links": [
                    [0, "Power", 0],
                ],
            },
            "column 2": {"data": "new column"},
            "Power": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "POWER",
                    "clamp": True,
                },
            },
        },
    )

    ny_table.new(
        group,
        {
            "in": {
                "data": cnt.new("NodeGroupInput"),
                "links": [
                    [0, "Separate XYZ", 0],
                    [1, ["Z", "Map Range"], 2],
                    [1, ["Z", "Map Range 2"], 2],
                    [2, ["Z", "Power"], 1],
                    [3, ["XY", "Power"], 1],
                ],
            },
            "column": {"data": "new column"},
            "Separate XYZ": {
                "data": cnt.new("ShaderNodeSeparateXYZ"),
                "height": 300,
                "links": [
                    [0, ["XY", "PingPong X"], 0],
                    [1, ["XY", "PingPong Y"], 0],
                    [2, ["Z", "Map Range"], 0],
                    [2, ["Z", "Map Range 2"], 0],
                ],
            },
            "column 2": {"data": "new column"},
            "Z": {
                "data": z,
                "links": [
                    ["Power", 0, "Multiply", 0],
                ],
            },
            "XY": {
                "data": xy,
                "links": [
                    ["Power", 0, "Multiply", 1],
                ],
            },
            "column 3": {"data": "new column"},
            "Multiply": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "MULTIPLY",
                    "clamp": True,
                },
                "links": [
                    [0, "out", 0],
                ],
            },
            "column 4": {"data": "new column"},
            "out": {
                "data": cnt.new("NodeGroupOutput"),
            },
        },
    )

    return group.name
