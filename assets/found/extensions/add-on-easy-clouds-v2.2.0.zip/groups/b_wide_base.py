import bpy
from ..neatify import ny_group, ny_table


def get_name():
    group = ny_group.new(
        "EC Wide Base Bounding",
        [
            {
                "name": "Vector",
                "type": "NodeSocketVector",
                "hidden": True,
            },
            {
                "name": "Z Mid",
                "value": 0.2,
                "min": 0,
                "max": 1,
                "subtype": "FACTOR",
            },
            {
                "name": "Z Power",
                "value": 1,
                "min": 0,
            },
            {
                "name": "XY Power",
                "value": 1,
                "min": 0,
            },
        ],
        [{"name": "Fac"}],
    )

    cnt = group.nodes

    xy = ny_table.new(
        group,
        {
            "Vector Add": {
                "data": cnt.new("ShaderNodeVectorMath"),
                "height": 200,
                "properties": {
                    "operation": "ADD",
                    "1": (-0.5, -0.5, 0),
                },
                "links": [
                    [0, "Vector Multiply", 0],
                ],
            },
            "column": {"data": "new column"},
            "Vector Multiply": {
                "data": cnt.new("ShaderNodeVectorMath"),
                "height": 200,
                "properties": {
                    "operation": "MULTIPLY",
                    "1": (2, 2, 0),
                },
                "links": [
                    [0, "Sphere Tex", 0],
                ],
            },
            "column 2": {"data": "new column"},
            "Sphere Tex": {
                "data": cnt.new("ShaderNodeTexGradient"),
                "properties": {
                    "gradient type": "SPHERICAL",
                },
                "links": [
                    [1, "Power", 0],
                ],
            },
            "column 3": {"data": "new column"},
            "Power": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "POWER",
                    "clamp": True,
                },
            },
        },
    )

    z = ny_table.new(
        group,
        {
            "Separate XYZ": {
                "data": cnt.new("ShaderNodeSeparateXYZ"),
                "links": [
                    [2, "Map Range", 0],
                    [2, "Map Range 2", 0],
                ],
            },
            "column": {"data": "new column"},
            "Map Range": {
                "data": cnt.new("ShaderNodeMapRange"),
                "height": 220,
                "links": [
                    [0, "Multiply", 0],
                ],
            },
            "Map Range 2": {
                "data": cnt.new("ShaderNodeMapRange"),
                "height": 220,
                "properties": {
                    "1": 1,
                },
                "links": [
                    [0, "Multiply", 1],
                ],
            },
            "column 2": {"data": "new column"},
            "Multiply": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "MULTIPLY",
                    "clamp": True,
                },
                "links": [
                    [0, "Power", 0],
                ],
            },
            "column 3": {"data": "new column"},
            "Power": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "POWER",
                    "clamp": True,
                },
            },
        },
    )

    ny_table.new(
        group,
        {
            "in": {
                "data": cnt.new("NodeGroupInput"),
                "links": [
                    [0, ["XY", "Vector Add"], 0],
                    [0, ["Z", "Separate XYZ"], 0],
                    [1, ["Z", "Map Range"], 2],
                    [1, ["Z", "Map Range 2"], 2],
                    [2, ["Z", "Power"], 1],
                    [3, ["XY", "Power"], 1],
                ],
            },
            "column": {"data": "new column"},
            "Z": {
                "data": z,
                "links": [
                    ["Power", 0, "Multiply", 0],
                ],
            },
            "XY": {
                "data": xy,
                "links": [
                    ["Power", 0, "Multiply", 1],
                ],
            },
            "column 2": {"data": "new column"},
            "Multiply": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "MULTIPLY",
                    "clamp": True,
                },
                "links": [
                    [0, "out", 0],
                ],
            },
            "column 3": {"data": "new column"},
            "out": {
                "data": cnt.new("NodeGroupOutput"),
            },
        },
    )

    return group.name
