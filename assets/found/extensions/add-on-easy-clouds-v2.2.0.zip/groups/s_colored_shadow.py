import bpy
from ..neatify import ny_group, ny_table


def get_name():
    group = ny_group.new(
        "EC EEVEE Cloud Volume",
        [
            {
                "name": "Color",
                "type": "NodeSocketColor",
                "value": (1, 1, 1, 1),
            },
            {
                "name": "Shadow Color",
                "type": "NodeSocketColor",
                "value": (0.15, 0.25, 0.8, 1),
            },
            {
                "name": "Texture",
                "hidden": True,
            },
            {
                "name": "Density",
                "value": 25,
                "min": 0,
            },
            {
                "name": "Anisotropy",
                "value": 0.4,
                "min": -1,
                "max": 1,
                "subtype": "FACTOR",
            },
        ],
        [
            {
                "name": "Volume",
                "type": "NodeSocketShader",
            },
        ],
    )

    cnt = group.nodes

    ny_table.new(
        group,
        {
            "in": {
                "data": cnt.new("NodeGroupInput"),
                "links": [
                    [0, "Principled Volume", 0],
                    [1, "Principled Volume", 7],
                    [2, "Multiply", 0],
                    [3, "Multiply", 1],
                    [4, "Principled Volume", 4],
                ],
            },
            "column": {"data": "new column"},
            "Multiply": {
                "data": cnt.new("ShaderNodeMath"),
                "properties": {
                    "operation": "MULTIPLY",
                },
                "links": [
                    [0, "Principled Volume", 2],
                    [0, "Principled Volume", 6],
                ],
            },
            "column 2": {"data": "new column"},
            "Principled Volume": {
                "data": cnt.new("ShaderNodeVolumePrincipled"),
                "width": 240,
                "height": 280,
                "links": [
                    [0, "out", 0],
                ],
            },
            "column 3": {"data": "new column"},
            "out": {
                "data": cnt.new("NodeGroupOutput"),
            },
        },
    )

    return group.name
