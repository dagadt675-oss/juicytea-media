import bpy


def new(x, y, z):
    x = x / 2
    y = y / 2
    z = z / 2

    verts = [
        (-x, -y, -z),
        (x, -y, -z),
        (x, y, -z),
        (-x, y, -z),
        (-x, -y, z),
        (x, -y, z),
        (x, y, z),
        (-x, y, z),
    ]
    faces = [
        (3, 2, 1, 0),
        (4, 5, 6, 7),
        (3, 7, 6, 2),
        (2, 6, 5, 1),
        (1, 5, 4, 0),
        (0, 4, 7, 3),
    ]

    mesh = bpy.data.meshes.new("EC Cloud Box")
    object = bpy.data.objects.new("EC Cloud Box", mesh)

    bpy.context.collection.objects.link(object)
    mesh.from_pydata(verts, [], faces)
    mesh.update(calc_edges=True)

    return object
