from .ny_group import FakeGroup


class NeatifyClassError(Exception):
    def __init__(self, message, function, class_name):
        self.message = f"Neatify class err: {message}\nClass {str(class_name)} in function {str(function)}"
        super().__init__(self.message)


class NeatifyTable:
    def __init__(self, gap=40):
        self.items = {}
        self.dimensions = [0, 0]
        self.gap = gap

    def add_columns(self, columns):
        for column in columns:
            for item in column.items.values():
                # Set items x zero location based on current table width
                item.zero_location[0] = self.dimensions[0]

            # Update table width
            self.dimensions[0] += column.dimensions[0] + self.gap

            # Update height if needed
            if self.dimensions[1] < column.dimensions[1]:
                self.dimensions[1] = column.dimensions[1]

            # Add column items to table
            self.items.update(column.items)

        # Remove trailing gap from width
        self.dimensions[0] -= self.gap

        # To make things look a bit nicer now that we have the tables height, loop over columns again and center their nodes
        for column in columns:
            centered_y = (self.dimensions[1] - column.dimensions[1]) / 2
            for item in column.items.values():
                item.zero_location[1] -= centered_y

    def get_item(self, item_key):
        if not item_key in self.items:
            raise NeatifyClassError(
                f'No item "{str(item_key)}"', "get_item", type(self)
            )

        return self.items[item_key]

    def get_node_ref(self, ref_info):
        def error_bad_info():
            raise NeatifyClassError(
                f"Bad data: {str(ref_info)}. Must be string or [string, string] or [string, list]",
                "get_node_ref",
                type(self),
            )

        match ref_info:
            case str():
                return self.get_item(ref_info).get_data(1)
            case list():
                if len(ref_info) != 2:
                    error_bad_info()

                return self.get_item(ref_info[0]).get_data(-1).get_node_ref(ref_info[1])
            case _:
                error_bad_info()

    def set_locations(self, location):
        # if item is a table, grab the table and call this function based on its item zero location
        for item in self.items.values():
            zeroed_location = (
                item.zero_location[0] + location[0],
                item.zero_location[1] + location[1],
            )
            if type(item.data) == NeatifyTable:
                item.data.set_locations(zeroed_location)
                continue

            item.data.location = zeroed_location

    def set_links(self, links, linker):
        def error_bad_info():
            raise NeatifyClassError(
                f"Bad data: {str(links)}. Must be [int, string or list, int] or [string or list, int, string or list, int]",
                "get_node_ref",
                type(self),
            )

        for link_key, link_values in links.items():
            for link in link_values:
                if type(link) != list:
                    error_bad_info()

                match len(link):
                    case 3:
                        if type(link[0]) != int or type(link[2]) != int:
                            error_bad_info()

                        linker(
                            self.get_node_ref(link_key).outputs[link[0]],
                            self.get_node_ref(link[1]).inputs[link[2]],
                        )
                    case 4:
                        if type(link[1]) != int or type(link[3]) != int:
                            error_bad_info()

                        linker(
                            self.get_node_ref([link_key, link[0]]).outputs[link[1]],
                            self.get_node_ref(link[2]).inputs[link[3]],
                        )
                    case _:
                        error_bad_info()

    def add_labels(self, label):
        for item in self.items.values():
            if item.data == NeatifyTable:
                item.data.add_labels(label)
                continue

            item.data.label = f"{label}.{item.data.label}"


# Columns are only used for calculating item relative positions
class NeatifyTableColumn:
    def __init__(self, table):
        self.items = {}
        self.table = table
        self.dimensions = [0, 0]

    # Must pass in item_info: "name": string, "item": NeatifyTableItem, "dimensions": (x, y)
    def add_item(self, item_info):
        self.items[item_info["name"]] = item_info["item"]

        # Update column width if needed
        if self.dimensions[0] < item_info["dimensions"][0]:
            self.dimensions[0] = item_info["dimensions"][0]

        # Add gap to height if not the first item
        if len(self.items) > 0:
            self.dimensions[1] += self.table.gap

        # set items zero_location
        item_info["item"].zero_location[1] = -self.dimensions[
            1
        ]  # Negative value of height to make nodes go down instead of up

        # update columns height
        self.dimensions[1] += item_info["dimensions"][1]


class NeatifyTableItem:
    def __init__(self, data):
        self.data = data
        self.zero_location = [0, 0]

    # error_on_table = 1 will error if data if another neatify table, -1 will error if data is not another table
    def get_data(self, should_be_node=0):
        if type(self.data) == NeatifyTable and should_be_node == 1:
            raise NeatifyClassError(
                f"Trying to access item data as a node, but item data is a table",
                "get_data",
                type(self),
            )
        elif type(self.data) != NeatifyTable and should_be_node == -1:
            raise NeatifyClassError(
                f"Trying to access item data as a table, but item data is a node",
                "get_data",
                type(self),
            )

        return self.data

    def set_properties(self, properties):
        self.get_data(1)  # Error if setting a property to a table

        for key, value in properties.items():
            try:
                key_int = int(key)
                self.data.inputs[key_int].default_value = value
            except ValueError:
                match key:
                    case "clamp":
                        self.data.use_clamp = value
                    case "clamp value":
                        self.data.clamp_value = value
                    case "clamp result":
                        self.data.clamp_result = value
                    case "clamp type":
                        self.data.clamp_type = value
                    case "blend type":
                        self.data.blend_type = value
                    case "data type":
                        self.data.data_type = value
                    case "operation":
                        self.data.operation = value
                    case "node tree":
                        self.data.node_tree = value
                    case "gradient type":
                        self.data.gradient_type = value
                    case "target":
                        self.data.target = value
                    case "normalize":
                        self.data.normalize = value


# -- Neatify New --
#
# - linker -
# reference to node_tree.nodes.link
#
# - items -
# dict, each item can consist of:
#     name: {
#         "data": node reference or table, (required)
#         "width": number,
#         "height": number,
#         "properties": {
#             "clamp": value,
#             "clamp value": value,
#             "clamp result": value,
#             "clamp type": value,
#             "blend type": value,
#             "data type": value,
#             "operation": value,
#             "node tree": value,
#             "gradient type": value,
#             "target": value,
#             "normalize": value,
#             addionntally keys that can be converted to int will be mapped to inputs[key].default_value. EX: "0": (0, 0, 0, 1) will set input 0 to black
#         },
#         "links": [
#             [output num, input node name, input num],
#             this can also reference a node inside a table
#             [output num, [input table name, node name], input num],
#             or from a table
#             [node name, output num, input node name, input num],
#             and can be recursive
#             [[item name, [items item name, item name]], output num, [input table name, [item name, [items item name, node name]]], output num]
#         ]
#     note that if data type is another NeatifyTable then only links will take effect
#
# To create a new column pass
#     name: { "data": any string }  ie: ("column_1": {"data": "new column"})
#
class NeatifyItemError(Exception):
    def __init__(self, message, item_name):
        self.message = f"{str(message)}\nItem: {str(item_name)}"
        super().__init__(self.message)


def new(node_tree, info_items):
    # If inside a group that already exists (checked in n_group.py), just return nothing
    if type(node_tree) == FakeGroup:
        return

    table = NeatifyTable()
    columns = [NeatifyTableColumn(table)]
    links = {}  # name: link values

    for key, value in info_items.items():
        # Check if there is data
        if not "data" in value:
            raise NeatifyItemError("No data in item", key)

        # Handle creating a new column
        if type(value["data"]) == str:
            columns.append(NeatifyTableColumn(table))
            continue

        item = NeatifyTableItem(value["data"])
        if type(item.data) == NeatifyTable:
            item.data.add_labels(key)

            # Add column item
            columns[-1].add_item(
                {"name": key, "item": item, "dimensions": item.data.dimensions}
            )
        else:
            # Set nodes label to name
            item.data.label = key

            # Set properties
            if "properties" in value:
                item.set_properties(value["properties"])

            # Grab dimensions
            dimensions = [140, 140]
            if "width" in value:
                dimensions[0] = value["width"]
            if "height" in value:
                dimensions[1] = value["height"]

            # Add column item
            columns[-1].add_item({"name": key, "item": item, "dimensions": dimensions})

        # Create links
        if "links" in value:
            links[key] = value["links"]

    table.add_columns(
        columns
    )  # Adds the columns to the table and also adds all column items to the table

    # Set links after all items have been added
    table.set_links(links, node_tree.links.new)

    table.set_locations((0, 0))

    return table
