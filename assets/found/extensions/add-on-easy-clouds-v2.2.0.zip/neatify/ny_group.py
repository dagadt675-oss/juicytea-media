import bpy


# -- Group New --
#
# - name -
# str
#
# - inputs -
# list, each item can consist of:
#     {
#         "name": string, (required)
#         "type": value,
#         "subtype": value,
#         "hidden": value,
#         "value": value, (maps to default_value)
#         "min": value,
#         "max": value,
#     },
#
# - outputs -
# list, each item can consist of:
#     {
#         "name": string, (required)
#         "type": value,
#         "value": value, (maps to default_value)
#         "min": value,
#         "max": value,
#     },
#
class FakeGroup:
    def __init__(self, name):
        self.name = name

    class nodes:
        def __init__(self):
            self.nothing = None

        def new(self, *args):
            return None


def new(name, inputs=[], outputs=[]):
    # If this group already exists return a fake group to not break other code
    if name in bpy.data.node_groups:
        return FakeGroup(name)

    group = bpy.data.node_groups.new(name, "ShaderNodeTree")

    for inp in inputs:
        soc = group.interface.new_socket(
            inp["name"],
            in_out="INPUT",
            socket_type=(inp["type"] if "type" in inp else "NodeSocketFloat"),
        )
        for key, value in inp.items():
            match key:
                case "subtype":
                    soc.subtype = value
                case "hidden":
                    soc.hide_value = value
                case "value":
                    soc.default_value = value
                case "min":
                    soc.min_value = value
                case "max":
                    soc.max_value = value
                case _:
                    continue

    for out in outputs:
        soc = group.interface.new_socket(
            out["name"],
            in_out="OUTPUT",
            socket_type=(out["type"] if "type" in out else "NodeSocketFloat"),
        )
        for key, value in out.items():
            match key:
                case "value":
                    soc.default_value = value
                case "min":
                    soc.min_value = value
                case "max":
                    soc.max_value = value
                case _:
                    continue

    return group
